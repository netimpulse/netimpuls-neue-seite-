# AGENTS.md (optional example for Codex)

This repository contains Shopify theme development skills under `.agents/skills`.

General workflow:
- Read relevant skills before creating, editing, or reviewing Shopify theme code.
- For Shopify Liquid/theme work, use `$shopify-workflow-coordinator` when possible.
- For Liquid implementation, use `$shopify-liquid`.
- For strict technical checks, use `$shopify-technical-reviewer`.
- For frontend, UX, accessibility, and production readiness review, use `$shopify-frontend-production-reviewer`.
- For setting up a new shop/repository workflow, use `$neuer-shop`.

Do not claim repository-wide review unless all relevant files were actually inspected.
